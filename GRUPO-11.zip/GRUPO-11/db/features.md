| Variable Name                | Role    | Type       |
|------------------------------|---------|------------|
| Gender                       | Feature | Binary     |
| Age                          | Feature | Continuous |
| Height                       | Feature | Continuous |
| Weight                       | Feature | Continuous |
| family_history_with_overweight | Feature | Binary   |
| FAVC                         | Feature | Binary    |
| FCVC                         | Feature | Integer   |
| NCP                          | Feature | Continuous|
| CAEC                         | Feature | Categorical|
| SMOKE                        | Feature | Binary    |
| CH2O                         | Feature | Continuous|
| SCC                          | Feature | Binary    |
| FAF                          | Feature | Continuous|
| TUE                          | Feature | Integer   |
| CALC                         | Feature | Categorical|
| MTRANS                       | Feature | Categorical|